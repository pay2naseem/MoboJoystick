import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const PSJoystickApp());
}

const Color neonBlue = Color(0xFF168CFF);
const Color deepBlue = Color(0xFF06142B);

class PSJoystickApp extends StatelessWidget {
  const PSJoystickApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'PS Joystick',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFF030711),
        colorScheme: ColorScheme.fromSeed(
          seedColor: neonBlue,
          brightness: Brightness.dark,
        ),
        fontFamily: 'Roboto',
      ),
      home: const ControllerScreen(),
    );
  }
}

class ControllerScreen extends StatefulWidget {
  const ControllerScreen({super.key});

  @override
  State<ControllerScreen> createState() => _ControllerScreenState();
}

class _ControllerScreenState extends State<ControllerScreen> {
  static const _channel = MethodChannel('ps_joystick/bluetooth_hid');
  String _connection = 'Not connected';
  bool _busy = false;
  final Set<String> _pressed = {};

  Future<void> _connect() async {
    setState(() => _busy = true);
    try {
      final result = await _channel.invokeMethod<String>('connect');
      setState(() => _connection = result ?? 'HID status unavailable');
    } on PlatformException catch (e) {
      setState(() => _connection = e.message ?? 'Bluetooth HID unavailable');
    } on MissingPluginException {
      setState(() => _connection = 'Native HID bridge not installed');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _send(String control, bool down) async {
    setState(() {
      if (down) {
        _pressed.add(control);
      } else {
        _pressed.remove(control);
      }
    });
    try {
      await _channel.invokeMethod('button', {'control': control, 'down': down});
    } catch (_) {
      // UI remains usable while the native HID layer is being implemented.
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment(-0.7, -0.8),
            radius: 1.4,
            colors: [Color(0xFF102D62), Color(0xFF050B19), Color(0xFF02040A)],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 14, 20, 10),
                child: Row(
                  children: [
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        gradient: const LinearGradient(
                          colors: [Color(0xFF227DFF), Color(0xFF092C70)],
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: neonBlue.withOpacity(.35),
                            blurRadius: 22,
                            spreadRadius: 1,
                          )
                        ],
                      ),
                      child: const Icon(Icons.gamepad_rounded, size: 28),
                    ),
                    const SizedBox(width: 12),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('PS Joystick',
                              style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                          Text('LIQUID GLASS CONTROLLER',
                              style: TextStyle(fontSize: 10, letterSpacing: 1.6, color: Color(0xFF9FC9FF))),
                        ],
                      ),
                    ),
                    GlassIconButton(icon: Icons.settings_rounded, onTap: () {
                      showDialog(context: context, builder: (_) => AlertDialog(
                        title: const Text('Controller settings'),
                        content: const Text('Sensitivity, button mapping and themes can be added after Bluetooth HID is validated.'),
                        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))],
                      ));
                    }),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: GlassPanel(
                  radius: 20,
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  child: Row(
                    children: [
                      Container(
                        width: 38,
                        height: 38,
                        decoration: BoxDecoration(
                          color: neonBlue.withOpacity(.18),
                          shape: BoxShape.circle,
                          border: Border.all(color: neonBlue.withOpacity(.6)),
                        ),
                        child: const Icon(Icons.bluetooth, color: Color(0xFF69B6FF)),
                      ),
                      const SizedBox(width: 12),
                      Expanded(child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(_connection, style: const TextStyle(fontWeight: FontWeight.w700)),
                          const SizedBox(height: 2),
                          const Text('Bluetooth HID • prototype', style: TextStyle(color: Color(0xFF9BAFCB), fontSize: 12)),
                        ],
                      )),
                      FilledButton(
                        onPressed: _busy ? null : _connect,
                        style: FilledButton.styleFrom(backgroundColor: const Color(0xFF126DFF)),
                        child: Text(_busy ? '...' : 'CONNECT'),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Expanded(
                child: LayoutBuilder(builder: (context, c) {
                  final landscape = c.maxWidth > c.maxHeight;
                  return SingleChildScrollView(
                    padding: const EdgeInsets.fromLTRB(12, 4, 12, 14),
                    child: Column(
                      children: [
                        GlassPanel(
                          radius: 30,
                          padding: EdgeInsets.symmetric(horizontal: landscape ? 18 : 12, vertical: 14),
                          child: Column(
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  TriggerButton(label: 'L2', active: _pressed.contains('L2'), onChanged: (v) => _send('L2', v)),
                                  TriggerButton(label: 'L1', active: _pressed.contains('L1'), onChanged: (v) => _send('L1', v)),
                                  const Spacer(),
                                  TriggerButton(label: 'R1', active: _pressed.contains('R1'), onChanged: (v) => _send('R1', v)),
                                  TriggerButton(label: 'R2', active: _pressed.contains('R2'), onChanged: (v) => _send('R2', v)),
                                ],
                              ),
                              const SizedBox(height: 16),
                              Container(
                                height: 74,
                                width: landscape ? 280 : 220,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(20),
                                  color: const Color(0xFF08162D).withOpacity(.85),
                                  border: Border.all(color: neonBlue.withOpacity(.7)),
                                  boxShadow: [BoxShadow(color: neonBlue.withOpacity(.18), blurRadius: 24)],
                                ),
                                child: const Center(
                                  child: Text('PS  •  TOUCHPAD',
                                    style: TextStyle(letterSpacing: 3, color: Color(0xFF8FC8FF), fontWeight: FontWeight.w600)),
                                ),
                              ),
                              const SizedBox(height: 16),
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Expanded(child: DPad(onControl: _send, pressed: _pressed)),
                                  Column(
                                    children: [
                                      SmallAction(label: 'SHARE', onChanged: (v) => _send('SHARE', v), active: _pressed.contains('SHARE')),
                                      const SizedBox(height: 16),
                                      CircleButton(label: 'PS', size: 54, active: _pressed.contains('PS'),
                                        onChanged: (v) => _send('PS', v)),
                                      const SizedBox(height: 16),
                                      SmallAction(label: 'OPTIONS', onChanged: (v) => _send('OPTIONS', v), active: _pressed.contains('OPTIONS')),
                                    ],
                                  ),
                                  Expanded(child: FaceButtons(onControl: _send, pressed: _pressed)),
                                ],
                              ),
                              const SizedBox(height: 18),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                children: [
                                  AnalogStick(label: 'L-STICK', onMove: (x, y) => _send('LX:${x.toStringAsFixed(2)},LY:${y.toStringAsFixed(2)}', true)),
                                  AnalogStick(label: 'R-STICK', onMove: (x, y) => _send('RX:${x.toStringAsFixed(2)},RY:${y.toStringAsFixed(2)}', true)),
                                ],
                              ),
                              const SizedBox(height: 12),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Icons.circle, size: 8, color: _connection == 'Not connected' ? Colors.orangeAccent : Colors.greenAccent),
                                  const SizedBox(width: 7),
                                  Flexible(child: Text(_connection, style: const TextStyle(fontSize: 11, color: Color(0xFFB7C8E4)))),
                                ],
                              )
                            ],
                          ),
                        ),
                        const SizedBox(height: 12),
                        const Text('Prototype UI • Bluetooth gamepad compatibility not yet verified',
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 11, color: Color(0xFF8294B2))),
                      ],
                    ),
                  );
                }),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class GlassPanel extends StatelessWidget {
  const GlassPanel({super.key, required this.child, this.padding = const EdgeInsets.all(12), this.radius = 20});
  final Widget child;
  final EdgeInsets padding;
  final double radius;

  @override
  Widget build(BuildContext context) => ClipRRect(
    borderRadius: BorderRadius.circular(radius),
    child: BackdropFilter(
      filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
      child: Container(
        padding: padding,
        decoration: BoxDecoration(
          color: const Color(0xFF0C1B32).withOpacity(.62),
          borderRadius: BorderRadius.circular(radius),
          border: Border.all(color: const Color(0xFF8AC7FF).withOpacity(.28)),
          boxShadow: [BoxShadow(color: neonBlue.withOpacity(.07), blurRadius: 24)],
        ),
        child: child,
      ),
    ),
  );
}

class GlassIconButton extends StatelessWidget {
  const GlassIconButton({super.key, required this.icon, required this.onTap});
  final IconData icon;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => Material(
    color: Colors.white.withOpacity(.06),
    shape: const CircleBorder(),
    child: InkWell(onTap: onTap, customBorder: const CircleBorder(),
      child: Container(width: 44, height: 44, decoration: BoxDecoration(
        shape: BoxShape.circle, border: Border.all(color: Colors.white.withOpacity(.18))),
        child: Icon(icon, color: const Color(0xFFC8E4FF)))),
  );
}

class TriggerButton extends StatelessWidget {
  const TriggerButton({super.key, required this.label, required this.active, required this.onChanged});
  final String label;
  final bool active;
  final ValueChanged<bool> onChanged;
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTapDown: (_) => onChanged(true), onTapUp: (_) => onChanged(false), onTapCancel: () => onChanged(false),
    child: AnimatedContainer(
      duration: const Duration(milliseconds: 100),
      width: 54, height: 42, alignment: Alignment.center,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        gradient: LinearGradient(colors: active ? [neonBlue, const Color(0xFF103A81)] : [const Color(0xFF253955), const Color(0xFF081326)]),
        border: Border.all(color: active ? const Color(0xFF8ED0FF) : Colors.white.withOpacity(.22)),
        boxShadow: active ? [BoxShadow(color: neonBlue.withOpacity(.45), blurRadius: 14)] : [],
      ),
      child: Text(label, style: const TextStyle(fontWeight: FontWeight.w800)),
    ),
  );
}

class SmallAction extends StatelessWidget {
  const SmallAction({super.key, required this.label, required this.active, required this.onChanged});
  final String label;
  final bool active;
  final ValueChanged<bool> onChanged;
  @override
  Widget build(BuildContext context) => Column(
    children: [
      Text(label, style: const TextStyle(fontSize: 9, letterSpacing: 1.1, color: Color(0xFFB7C9E5))),
      const SizedBox(height: 5),
      GestureDetector(
        onTapDown: (_) => onChanged(true), onTapUp: (_) => onChanged(false), onTapCancel: () => onChanged(false),
        child: AnimatedContainer(duration: const Duration(milliseconds: 100),
          width: 31, height: 31,
          decoration: BoxDecoration(shape: BoxShape.circle,
            gradient: LinearGradient(colors: active ? [neonBlue, deepBlue] : [const Color(0xFF253A5A), const Color(0xFF071020)]),
            border: Border.all(color: Colors.white.withOpacity(.3))),
          child: const SizedBox.shrink()),
      ),
    ],
  );
}

class CircleButton extends StatelessWidget {
  const CircleButton({super.key, required this.label, required this.size, required this.active, required this.onChanged});
  final String label; final double size; final bool active; final ValueChanged<bool> onChanged;
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTapDown: (_) => onChanged(true), onTapUp: (_) => onChanged(false), onTapCancel: () => onChanged(false),
    child: AnimatedContainer(duration: const Duration(milliseconds: 100), width: size, height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(shape: BoxShape.circle,
        gradient: LinearGradient(colors: active ? [neonBlue, deepBlue] : [const Color(0xFF263D5C), const Color(0xFF050B15)]),
        border: Border.all(color: active ? const Color(0xFF7AC7FF) : Colors.white.withOpacity(.3)),
        boxShadow: [BoxShadow(color: neonBlue.withOpacity(active ? .45 : .12), blurRadius: 13)]),
      child: Text(label, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 12))),
  );
}

class DPad extends StatelessWidget {
  const DPad({super.key, required this.onControl, required this.pressed});
  final Future<void> Function(String, bool) onControl;
  final Set<String> pressed;
  @override
  Widget build(BuildContext context) => SizedBox(
    width: 126, height: 126,
    child: Stack(alignment: Alignment.center, children: [
      for (final d in [
        ('UP', Alignment.topCenter, Icons.keyboard_arrow_up),
        ('DOWN', Alignment.bottomCenter, Icons.keyboard_arrow_down),
        ('LEFT', Alignment.centerLeft, Icons.keyboard_arrow_left),
        ('RIGHT', Alignment.centerRight, Icons.keyboard_arrow_right),
      ])
        Align(alignment: d.$2, child: GestureDetector(
          onTapDown: (_) => onControl(d.$1, true), onTapUp: (_) => onControl(d.$1, false), onTapCancel: () => onControl(d.$1, false),
          child: AnimatedContainer(duration: const Duration(milliseconds: 100), width: 42, height: 42,
            decoration: BoxDecoration(
              color: pressed.contains(d.$1) ? neonBlue.withOpacity(.65) : const Color(0xFF111F35),
              borderRadius: BorderRadius.circular(11),
              border: Border.all(color: Colors.white.withOpacity(.23)),
              boxShadow: [BoxShadow(color: neonBlue.withOpacity(.08), blurRadius: 8)]),
            child: Icon(d.$3, size: 29, color: const Color(0xFFD9ECFF))))),
      Container(width: 37, height: 37, decoration: BoxDecoration(color: const Color(0xFF0B1728), borderRadius: BorderRadius.circular(8))),
    ]),
  );
}

class FaceButtons extends StatelessWidget {
  const FaceButtons({super.key, required this.onControl, required this.pressed});
  final Future<void> Function(String, bool) onControl;
  final Set<String> pressed;
  @override
  Widget build(BuildContext context) => SizedBox(
    height: 132,
    child: Stack(children: [
      Positioned(top: 0, left: 43, child: _face('△', 'TRIANGLE', const Color(0xFF3EE9D0))),
      Positioned(top: 37, left: 0, child: _face('□', 'SQUARE', const Color(0xFFFF69D5))),
      Positioned(top: 37, right: 0, child: _face('○', 'CIRCLE', const Color(0xFFFF5B79))),
      Positioned(top: 74, left: 43, child: _face('×', 'CROSS', const Color(0xFF53A8FF))),
    ]),
  );

  Widget _face(String glyph, String key, Color glow) => GestureDetector(
    onTapDown: (_) => onControl(key, true), onTapUp: (_) => onControl(key, false), onTapCancel: () => onControl(key, false),
    child: AnimatedContainer(duration: const Duration(milliseconds: 100), width: 42, height: 42,
      alignment: Alignment.center,
      decoration: BoxDecoration(shape: BoxShape.circle,
        gradient: LinearGradient(colors: pressed.contains(key) ? [glow.withOpacity(.8), const Color(0xFF071020)] : [const Color(0xFF263B59), const Color(0xFF050B15)]),
        border: Border.all(color: glow.withOpacity(.75)),
        boxShadow: [BoxShadow(color: glow.withOpacity(.22), blurRadius: 10)]),
      child: Text(glyph, style: TextStyle(fontSize: 24, fontWeight: FontWeight.w500, color: glow))),
  );
}

class AnalogStick extends StatefulWidget {
  const AnalogStick({super.key, required this.label, required this.onMove});
  final String label;
  final void Function(double, double) onMove;
  @override
  State<AnalogStick> createState() => _AnalogStickState();
}

class _AnalogStickState extends State<AnalogStick> {
  Offset _offset = Offset.zero;
  static const double radius = 49;
  void _update(Offset local) {
    final delta = local - const Offset(radius, radius);
    final d = delta.distance;
    final clamped = d > 25 ? delta / d * 25 : delta;
    setState(() => _offset = clamped);
    widget.onMove(clamped.dx / 25, clamped.dy / 25);
  }
  @override
  Widget build(BuildContext context) => Column(children: [
    SizedBox(width: 98, height: 98,
      child: GestureDetector(
        onPanStart: (d) => _update(d.localPosition),
        onPanUpdate: (d) => _update(d.localPosition),
        onPanEnd: (_) { setState(() => _offset = Offset.zero); widget.onMove(0, 0); },
        child: Container(
          decoration: BoxDecoration(shape: BoxShape.circle,
            gradient: const RadialGradient(colors: [Color(0xFF172C4B), Color(0xFF050A13)]),
            border: Border.all(color: neonBlue.withOpacity(.7), width: 2),
            boxShadow: [BoxShadow(color: neonBlue.withOpacity(.25), blurRadius: 17)]),
          child: Stack(alignment: Alignment.center, children: [
            Container(width: 70, height: 70, decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: Colors.white.withOpacity(.12), width: 5))),
            Transform.translate(offset: _offset, child: Container(width: 49, height: 49,
              decoration: BoxDecoration(shape: BoxShape.circle,
                gradient: const RadialGradient(colors: [Color(0xFF354A68), Color(0xFF070C15)]),
                border: Border.all(color: const Color(0xFF80C5FF), width: 1.5),
                boxShadow: [BoxShadow(color: neonBlue.withOpacity(.35), blurRadius: 10)]))),
          ]),
        ),
      )),
    const SizedBox(height: 7),
    Text(widget.label, style: const TextStyle(fontSize: 9, letterSpacing: 1.5, color: Color(0xFF9DBDE5))),
  ]);
}
