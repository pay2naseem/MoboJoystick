# PS Joystick — Flutter Starter

A dark Liquid Glass / DualSense-inspired controller UI prototype for Android and iOS, plus an Android-native Bluetooth HID proof-of-concept scaffold.

## Important compatibility note
This starter is **not yet a verified working Bluetooth gamepad**. The Flutter controller UI works locally, but Bluetooth HID device registration/report transmission must be tested on a physical Android phone and then validated against the target iPad/Windows PC. Android's HID API availability and host acceptance vary by device/OS. The iOS target currently provides the UI only; iOS does not expose Android's `BluetoothHidDevice` API.

## Create the Flutter project

Install Flutter and Android Studio, then run:

```bash
flutter create ps_joystick
cd ps_joystick
```

Copy the `lib/` directory and `pubspec.yaml` from this archive into the project, replacing existing files. Copy `android/app/src/main/kotlin/` and merge the manifest permissions from `android/AndroidManifest.xml` into your generated project's manifest.

Then run:

```bash
flutter pub get
flutter run
```

## Bluetooth HID status

The included Kotlin bridge exposes capability/status placeholders and demonstrates the Flutter platform-channel boundary. It deliberately does not claim successful pairing or input transmission yet. Complete the native implementation against Android's `BluetoothHidDevice` API, add a valid HID gamepad descriptor, and test on-device before relying on it for games.

## Testing sequence

1. Verify the UI on Android.
2. Test the Kotlin Bluetooth profile availability on the actual phone.
3. Implement and verify HID registration + input reports.
4. Attempt pairing from iPad Settings > Bluetooth.
5. Verify actual input in an iPad game that supports external controllers.
6. Repeat on Windows. A Bluetooth pairing icon alone is not proof that the device is recognized as a gamepad.

## iOS build
iOS builds require macOS and Xcode. The UI can run on iPad, but this starter does not make an iPhone/iPad app emulate a generic Bluetooth HID gamepad.
