package com.example.ps_joystick

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.os.Build
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val channelName = "ps_joystick/bluetooth_hid"
    private var hidDevice: BluetoothHidDevice? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "connect" -> {
                        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
                            result.error("UNSUPPORTED", "Bluetooth HID Device requires Android 9/API 28 or later.", null)
                        } else {
                            val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
                            val adapter: BluetoothAdapter? = manager.adapter
                            if (adapter == null || !adapter.isEnabled) {
                                result.error("BLUETOOTH_OFF", "Enable Bluetooth in Android Settings first.", null)
                            } else {
                                // TODO: request runtime BLUETOOTH_CONNECT/ADVERTISE permissions.
                                // TODO: adapter.getProfileProxy(..., BluetoothProfile.HID_DEVICE)
                                // TODO: registerApp(valid HID descriptor, subclass, ...)
                                // TODO: handle onAppStatusChanged/onConnectionStateChanged callbacks.
                                result.success("Bluetooth available; HID registration not implemented yet")
                            }
                        }
                    }
                    "button" -> {
                        val control = call.argument<String>("control") ?: ""
                        val down = call.argument<Boolean>("down") ?: false
                        // TODO: translate control state into a HID report and call
                        // BluetoothHidDevice.sendReport(device, reportId, reportBytes).
                        result.success(mapOf("accepted" to true, "control" to control, "down" to down))
                    }
                    else -> result.notImplemented()
                }
            }
    }
}
